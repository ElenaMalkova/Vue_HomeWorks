# Fork-able normalize-scss<br> for Sass

## Using with Sass

1. Copy these files to your Sass project.
2. Start forking by altering/moving Sass variables found in `_variables.scss`.
3. Edit any CSS ruleset directly rather than overriding it in later Sass.
